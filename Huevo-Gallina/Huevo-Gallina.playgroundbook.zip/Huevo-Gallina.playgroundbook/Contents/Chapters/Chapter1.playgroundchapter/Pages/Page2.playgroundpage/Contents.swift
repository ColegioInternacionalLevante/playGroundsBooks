/*:
# ¿Y ahora qué?

 Bueno, el verdadero potencial de un `PlaygroundBook` es doble. Por un lado, puedes intervenir en él y por otro, te ayuda a aprender y comprender conceptos de programación en lenguage Swift de Apple.
 
 Empecemos por la primera parte:
 
 ### Hagamos crecer el juego
 
 Estás jugando a un juego de ubicar cronológicamente inventos, pero solo hay unos pocos y se hace aburrido. ¿Qué tal si investigas un poco y'
 añades unos cuantos inventos al juego? En una clase de veinte alumnos, por ejemplo, si cada uno aporta dos nuevos inventos a la aplicación, ¡tendríais 40 nuevos inventos para jugar!
 
 Para añadir un nuevo invento recuerda que necesitarás:
 
 - El nombre del invento.
 - El año de invención.
 - Una imagen en **formato PNG** *(a ser posible sin fondo)* que podéis descargar de internet.
 - Una pequeña pista o información que pueda permitir al jugador ubicar temporalmente el invento. 
 
 Toda esta información la introduciremos en el programa copiando la estructura que ves abajo. En el lugar donde pone **Toca para ingresar el código**.

*/
//#-hidden-code
import Foundation
import UIKit
import PlaygroundSupport
import GameplayKit

public struct Inventos {
    var nombre: String
    var imagenInvento: UIImage
    var añoInvento: Int
    var numero: String
    var pista: String
}

let Vapor = Inventos(nombre: "Máquina de Vapor", imagenInvento: UIImage(imageLiteralResourceName: "Maquinavapor.jpeg"), añoInvento: 1775, numero: "1775", pista: "El salvaje oeste pudo conquistarse gracias a ella")

let Telefono = Inventos(nombre: "Teléfono", imagenInvento: UIImage(imageLiteralResourceName: "Telefono.PNG"), añoInvento: 1870, numero: "1870", pista: "Se invento en el tércio final del SXIX")

let Automovil = Inventos(nombre: "Automóvil", imagenInvento: UIImage(imageLiteralResourceName: "Automovil.PNG"), añoInvento: 1885, numero: "1885", pista: "El coche llegó al mundo apenas tres años después que la bombilla.")

let Bombilla = Inventos(nombre: "Bombilla", imagenInvento: UIImage(imageLiteralResourceName: "Bombilla.PNG"), añoInvento: 1881, numero: "1881", pista: "La bombilla inauguro la octava década del SXIX.")

let Avion = Inventos(nombre: "Avión", imagenInvento: UIImage(imageLiteralResourceName: "Avion.PNG"), añoInvento: 1903, numero: "1903", pista: "Surcó el cielo inaugurando el SXX")

let Bicicleta = Inventos(nombre: "Bicicleta", imagenInvento: UIImage(imageLiteralResourceName: "Bicicleta.PNG"), añoInvento: 1839, numero: "1839", pista: "Primera mitad del SXIX")

let Cine = Inventos(nombre: "Cinematógrafo", imagenInvento: UIImage(imageLiteralResourceName: "Cinematografo.PNG"), añoInvento: 1895, numero: "1895", pista: "En 1995 se celebró el primer centenario de su invención")

let fregona = Inventos(nombre: "Fregona", imagenInvento: UIImage(imageLiteralResourceName: "Fregona.PNG"), añoInvento: 1964, numero: "1964", pista: "La inventó un español: Manuel Jalón Corominas y a pesar de que parece que lleva mucho tiempo con nosotros, apenas hace 60 años que tomó la forma que tiene ahora.")

let Videoconsola = Inventos (nombre: "Videoconsola", imagenInvento: UIImage(imageLiteralResourceName: "Videoconsola.PNG"), añoInvento: 1972, numero: "1972", pista: "La primera se llamó 'Magnavox Odissey' y permitió jugar en casa a videojuegos que hasta ese momento solo se jugaban en salones recreativos. Salió al mercado 3 años después de que el hombre llegara a la Luna.")
//#-end-hidden-code
let Radio = Inventos (nombre: "Radio", imagenInvento: UIImage(imageLiteralResourceName: "Radio.JPG"), añoInvento: 1907, numero: "1907", pista: "El SXX empezó con este maravilloso invento que nos acompaña hasta hoy.")
/*:
 - Declara la constante `let`.
 - Después pon el nombre de tu nuevo invento.
 - En tercer lugar, introduce `Inventos` para decirle a la aplicación que este nuevo dato que creas corresponde al tipo `Inventos`.
 - Abre paréntesis. En este momento verás que en la barra de sugerencias te marca una gran frase con todas las opciones. Solo tienes que seleccionarla y rellenar todos los campos como aparecen arriba.
 */

//#-editable-code

//#-end-editable-code

//#-hidden-code
class PantallaDos: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func ganador(){
        botonReset.isHidden = false
        botonCambioJugador.isHidden = true
        pantallaCartas.isEditing = false
        navigationItem.rightBarButtonItem?.isEnabled = false
        navigationItem.hidesBackButton = true
        let triunfo = UIAlertController(title: "ENHORABUENA", message: "¡Eres el ganador!", preferredStyle: UIAlertControllerStyle.alert)
        triunfo.addAction(UIAlertAction(title: "Volver", style: UIAlertActionStyle.default, handler: nil))
        present(triunfo, animated: true, completion: nil)
    }
    func cambioJugador() {
        show(Pantalla(), sender: nil)
    }
    func botonResetPulsado() {
        acierto = 0
        aciertoDos = 0
        colocadas = 0
        cartasEnJuego = 0
        datoClaveContador = acierto as Int
        datoClaveContadorDos = aciertoDos as Int
        datoClave.set(datoClaveContador, forKey: "acierto")
        datoClave.set(datoClaveContadorDos, forKey: "aciertoDos")
        inventos.removeAll()
        pantallaCartas.reloadData()
        botonCarta.isHidden = false
        viewDidLoad()
    }
    func vuelta(){
        pantallaCartas.setEditing(false, animated: false)
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .edit, target: self, action: #selector(pista))
    }
    
    func pista() {
        pantallaCartas.setEditing(true, animated: true)
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(vuelta))
    }
    var inventos = [Inventos]()
    let datoClave = UserDefaults()
    var datoClaveContador: Int = 0
    var datoClaveContadorDos: Int = 0
    var cartasEnJuego = 0
    var puntos = UILabel(frame: CGRect(x: 50, y: 500, width: 50, height: 50))
    var puntosDos = UILabel(frame: CGRect(x: 50, y: 500, width: 50, height: 50))
    //#-end-hidden-code
/*:
     
Una vez hecho esto, para que el juego utilice el nuevo invento incorporado debes de incorporarlo a los dos `Arrays` que ves abajo. Para ello escribe el nombre del invento tal y como lo has hecho tras el `let` un poco más arriba.
     
*/

    var nutreInventos = [Vapor, Bombilla, Automovil, Bicicleta, Avion, Telefono, Cine, fregona, Videoconsola, Radio,/*#-editable-code*//*#-end-editable-code*/]
    
    //#-hidden-code
    let botonCarta = UIButton(frame: CGRect(x: 15, y: 50, width: 40, height: 40))
    let tituloJuego = UILabel()
    let pantallaCartas = UITableView(frame: CGRect(x: 5, y: 5, width: 600, height: 400))
    let creacion = UILabel(frame: CGRect(x: 150, y: 75, width: 120, height: 35))
    let botonCambioJugador = UIButton(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
    let botonReset = UIButton(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
    var acierto = 0
    var aciertoDos = 0
    var colocadas = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if datoClave.object(forKey: "acierto") == nil {
         if datoClave.object(forKey: "aciertoDos") == nil {
            
            }} else if datoClave.object(forKey: "acierto") as! Int >= 15 {
            acierto = 0
            aciertoDos = 0
            colocadas = 0
            cartasEnJuego = 0
            datoClaveContador = acierto as Int
            datoClaveContadorDos = aciertoDos as Int
            datoClave.set(datoClaveContador, forKey: "acierto")
            datoClave.set(datoClaveContadorDos, forKey: "aciertoDos")
            inventos.removeAll()
            pantallaCartas.reloadData()
            botonCarta.isHidden = false
        } else {
            acierto = datoClave.object(forKey: "acierto") as! Int
            if datoClave.object(forKey: "aciertoDos") == nil {
              
            } else {
            aciertoDos = datoClave.object(forKey: "aciertoDos") as! Int
            }}
        view.backgroundColor = .white
        botonCambioJugador.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0).withAlphaComponent(0.9)
        botonCambioJugador.layer.cornerRadius = 25
        botonCambioJugador.setTitle("👆🏻", for: .normal)
        botonCambioJugador.layer.borderWidth = 1
        botonCambioJugador.setTitleColor(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0), for: .normal)
        botonCambioJugador.isHidden = true
        botonCambioJugador.addTarget(nil, action: #selector(cambioJugador), for: .touchUpInside)
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .edit, target: self, action: #selector(pista))
        
        botonReset.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        botonReset.layer.cornerRadius = 25
        botonReset.setTitle("✖️", for: .normal)
        botonReset.layer.borderWidth = 1
        botonReset.setTitleColor(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0), for: .normal)
        botonReset.isHidden = false
        botonReset.addTarget(nil, action: #selector(botonResetPulsado), for: .touchUpInside)
        
        
        puntos.layer.borderWidth = 5
        puntos.textAlignment = .center
        puntos.font = UIFont(name: "PingFangTC-Medium", size: 20)
        puntos.text = "\(acierto)"
        puntos.backgroundColor = #colorLiteral(red: 0.6903506315, green: 0.9502549196, blue: 0.9764705896, alpha: 1)
        puntos.isEnabled = false
        
        puntosDos.layer.borderWidth = 5
        puntosDos.textAlignment = .center
        puntosDos.font = UIFont(name: "PingFangTC-Medium", size: 20)
        puntosDos.text = "\(aciertoDos)"
        puntosDos.backgroundColor = #colorLiteral(red: 0.960784316062927, green: 0.705882370471954, blue: 0.200000002980232, alpha: 1.0)
        
        botonCarta.backgroundColor = .red
        
        botonCarta.layer.cornerRadius = 35
        botonCarta.addTarget(nil, action: #selector(botonCartaPulsa), for: .touchUpInside)
        
        tituloJuego.text = "El huevo o la gallina"
        
        
        tituloJuego.adjustsFontSizeToFitWidth = true
        tituloJuego.textAlignment = .center
        tituloJuego.font = UIFont(name: "PingFangSC-Thin", size: 40)
        pantallaCartas.layer.cornerRadius = 15
        pantallaCartas.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        self.pantallaCartas.delegate = self
        self.pantallaCartas.dataSource = self
        pantallaCartas.rowHeight = 150
        pantallaCartas.setEditing(true, animated: true)
        
        view.addSubview(pantallaCartas)
        view.addSubview(tituloJuego)
        view.addSubview(botonCarta)
        view.addSubview(botonCambioJugador)
        view.addSubview(puntos)
        view.addSubview(puntosDos)
        view.addSubview(botonReset)
        
        botonReset.translatesAutoresizingMaskIntoConstraints = false
        puntos.translatesAutoresizingMaskIntoConstraints = false
        tituloJuego.translatesAutoresizingMaskIntoConstraints = false
        pantallaCartas.translatesAutoresizingMaskIntoConstraints = false
        botonCarta.translatesAutoresizingMaskIntoConstraints = false
        botonCambioJugador.translatesAutoresizingMaskIntoConstraints = false
        puntosDos.translatesAutoresizingMaskIntoConstraints = false
        
        let views = ["tituloJuego": tituloJuego, "pantallaCartas": pantallaCartas, "botonCarta": botonCarta, "botonCambioJugador": botonCambioJugador, "puntos": puntos, "botonReset": botonReset, "puntosDos": puntosDos]
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "|-25-[botonCarta(70)]", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "|-25-[tituloJuego]-25-|", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "|-35-[pantallaCartas]-35-|", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "|-25-[botonCambioJugador(50)]", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "[botonReset(50)]-25-|", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "|-25-[puntos(50)]", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "[puntosDos(50)]-25-|", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-50-[tituloJuego]-5-[pantallaCartas]-8-|", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-100-[botonCarta(70)]", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-250-[botonCambioJugador(50)]", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-250-[botonReset(50)]", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:[puntos(50)]-25-|", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:[puntosDos(50)]-25-|", options: [], metrics: nil, views: views))
    }
    func botonCartaPulsa(){
        if nutreInventos.count == 0 {
            title = "No hay más elementos."
        }else {
            for _ in 1 ... 3 {
                botonCarta.isHidden = true
                let randomChoice = GKRandomDistribution(lowestValue: 0, highestValue: nutreInventos.count - 1)
                let sign = randomChoice.nextInt()
                cartasEnJuego += 1
                print(cartasEnJuego)
                inventos.insert(nutreInventos[sign], at: 0)
                nutreInventos.remove(at: sign)
                
                pantallaCartas.beginUpdates()
                pantallaCartas.insertRows(at: [IndexPath.init(row: 0, section: 0)], with: UITableViewRowAnimation.left)
                pantallaCartas.endUpdates()
                
            }
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return inventos.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = UITableViewCell(style: .value2, reuseIdentifier: "celdaInventos")
        celda.backgroundColor = .white
        let fondoCarta = UIView(frame: CGRect(x: 60, y: 15, width: 25, height: 25))
        let imagenInvento = UIImageView(frame: CGRect(x: 25, y: 55, width: 100, height: 70))
        let nombreInvento = UILabel(frame: CGRect(x: 15, y: 15, width: 125, height: 35))
        let textoInvento = UILabel(frame: CGRect(x: 10, y: 168, width: 130, height: 70))
        
        
        fondoCarta.layer.cornerRadius = 8
        
        imagenInvento.layer.cornerRadius = 8
        imagenInvento.image = inventos[indexPath.row].imagenInvento
        
        nombreInvento.text = inventos[indexPath.row].nombre
        nombreInvento.textAlignment = .center
        
        nombreInvento.font = UIFont(name: "PingFangSC-Thin", size: 25)
        nombreInvento.textColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        nombreInvento.adjustsFontSizeToFitWidth = true
        
        textoInvento.numberOfLines = 0
        textoInvento.textAlignment = .center
        textoInvento.backgroundColor = .white
        textoInvento.textColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        textoInvento.font = UIFont(name: "PingFangSC-Thin", size: 15)
        
        fondoCarta.addSubview(imagenInvento)
        fondoCarta.addSubview(nombreInvento)
        fondoCarta.addSubview(creacion)
        celda.contentView.addSubview(fondoCarta)
        
        fondoCarta.translatesAutoresizingMaskIntoConstraints = false
        imagenInvento.translatesAutoresizingMaskIntoConstraints = false
        nombreInvento.translatesAutoresizingMaskIntoConstraints = false
        
        let vistaCeldas = ["fondoCarta": fondoCarta, "imagenInvento": imagenInvento, "nombreInvento": nombreInvento, "creacion": creacion]
        
        celda.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "|-50-[fondoCarta]-50-|", options: [], metrics: nil, views: vistaCeldas))
        
        fondoCarta.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "|-40-[imagenInvento(80)]-10-|", options: [], metrics: nil, views: vistaCeldas))
        
        fondoCarta.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "|-5-[creacion(10)]", options: [], metrics: nil, views: vistaCeldas))
        
        fondoCarta.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "|-25-[nombreInvento]-10-|", options: [], metrics: nil, views: vistaCeldas))
        
        celda.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-5-[fondoCarta]-5-|", options: [], metrics: nil, views: vistaCeldas))
        
        fondoCarta.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-8-[nombreInvento]-10-[imagenInvento(80)]", options: [], metrics: nil, views: vistaCeldas))
        
        fondoCarta.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-15-[creacion(30)]", options: [], metrics: nil, views: vistaCeldas))
        
        fondoCarta.setNeedsDisplay()
        imagenInvento.setNeedsDisplay()
        nombreInvento.setNeedsDisplay()
        creacion.setNeedsDisplay()
        
        return celda
    }
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let pulsado = inventos[indexPath.row]
        let celdaSelccionada = pantallaCartas.cellForRow(at: indexPath)
        let datos = UIAlertController(title: pulsado.nombre, message: pulsado.pista, preferredStyle: UIAlertControllerStyle.alert)
        datos.addAction(UIAlertAction(title: "Volver", style: UIAlertActionStyle.default, handler: nil))
        present(datos, animated: true, completion: nil)
        
        celdaSelccionada?.isEditing = true
        
    }
    
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let itemToMove = inventos[sourceIndexPath.row]
        inventos.remove(at: sourceIndexPath.row)
        inventos.insert(itemToMove, at: destinationIndexPath.row)
        let posicion = destinationIndexPath.row
        let posicionArriba = destinationIndexPath.row - 1
        let posicionaAbajo = destinationIndexPath.row + 1
        _ = cartasEnJuego - 1
        let celdaEnJuego = pantallaCartas.cellForRow(at: sourceIndexPath)
        _ = 0
        
        if posicion == 0 {
            if itemToMove.añoInvento > inventos[posicionaAbajo].añoInvento{
                celdaEnJuego?.isEditing = false
                celdaEnJuego?.backgroundColor = #colorLiteral(red: 0.466666668653488, green: 0.764705896377563, blue: 0.266666680574417, alpha: 1.0)
                aciertoDos += 1
                puntosDos.text = "\(aciertoDos)"
                datoClaveContadorDos = aciertoDos as Int
                datoClave.set(datoClaveContadorDos, forKey: "aciertoDos")
                
                
                let creacion = UILabel(frame: CGRect(x: 200, y: 75, width: 120, height: 60))
                creacion.textColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
                creacion.font = UIFont(name: "PingFangSC-Thin", size: 40)
                creacion.textAlignment = .center
                creacion.text = itemToMove.numero
                celdaEnJuego?.contentView.addSubview(creacion)
                colocadas += 1
                if aciertoDos == 15 {
                    ganador()
                }
                if colocadas == 3 {
                    botonCambioJugador.isHidden = false
                    botonReset.isHidden = true
                }
            }else {
                celdaEnJuego?.isEditing = false
                celdaEnJuego?.backgroundColor = #colorLiteral(red: 0.925490200519562, green: 0.235294118523598, blue: 0.10196078568697, alpha: 1.0)
                colocadas += 1
                if colocadas == 3 {
                    botonCambioJugador.isHidden = false
                    botonReset.isHidden = true
                }
            }}
        if posicion == 1 {
            
            if itemToMove.añoInvento < inventos[posicionArriba].añoInvento && itemToMove.añoInvento > inventos[posicionaAbajo].añoInvento{
                celdaEnJuego?.isEditing = false
                celdaEnJuego?.backgroundColor = #colorLiteral(red: 0.466666668653488, green: 0.764705896377563, blue: 0.266666680574417, alpha: 1.0)
                aciertoDos += 1
                puntosDos.text = "\(aciertoDos)"
                datoClaveContadorDos = aciertoDos as Int
                datoClave.set(datoClaveContadorDos, forKey: "aciertoDos")
                
                let creacion = UILabel(frame: CGRect(x: 200, y: 75, width: 120, height: 60))
                
                creacion.textColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
                creacion.font = UIFont(name: "PingFangSC-Thin", size: 40)
                creacion.textAlignment = .center
                creacion.text = itemToMove.numero
                celdaEnJuego?.contentView.addSubview(creacion)
                colocadas += 1
                if aciertoDos == 15 {
                    ganador()
                }
                if colocadas == 3 {
                    botonCambioJugador.isHidden = false
                    botonReset.isHidden = true
                }
                
            }else {
                celdaEnJuego?.isEditing = false
                celdaEnJuego?.backgroundColor = #colorLiteral(red: 0.925490200519562, green: 0.235294118523598, blue: 0.10196078568697, alpha: 1.0)
                colocadas += 1
                if colocadas == 3 {
                    botonCambioJugador.isHidden = false
                    botonReset.isHidden = true
                }
            }
        }
        if posicion == 2  {
            if itemToMove.añoInvento < inventos[posicionArriba].añoInvento {
                celdaEnJuego?.isEditing = false
                celdaEnJuego?.backgroundColor = #colorLiteral(red: 0.466666668653488, green: 0.764705896377563, blue: 0.266666680574417, alpha: 1.0)
                aciertoDos += 1
                puntosDos.text = "\(aciertoDos)"
                datoClaveContadorDos = aciertoDos as Int
                datoClave.set(datoClaveContadorDos, forKey: "aciertoDos")
                let creacion = UILabel(frame: CGRect(x: 200, y: 75, width: 120, height: 60))
                creacion.font = UIFont(name: "PingFangSC-Thin", size: 40)
                creacion.textAlignment = .center
                creacion.text = itemToMove.numero
                creacion.textColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
                
                celdaEnJuego?.contentView.addSubview(creacion)
                colocadas += 1
                
                if colocadas == 3 {
                    botonCambioJugador.isHidden = false
                    botonReset.isHidden = true
                }
                if aciertoDos == 15 {
                    ganador()
                }
            }else{
                celdaEnJuego?.isEditing = false
                celdaEnJuego?.backgroundColor = #colorLiteral(red: 0.925490200519562, green: 0.235294118523598, blue: 0.10196078568697, alpha: 1.0)
                colocadas += 1
                if colocadas == 3 {
                    botonCambioJugador.isHidden = false
                    botonReset.isHidden = true
                }
            }
            
        }
        
    }
}

class Pantalla: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func ganador(){
        botonReset.isHidden = false
        botonCambioJugador.isHidden = true
        pantallaCartas.isEditing = false
        navigationItem.rightBarButtonItem?.isEnabled = false
        navigationItem.hidesBackButton = true
        let triunfo = UIAlertController(title: "ENHORABUENA", message: "¡Eres el ganador!", preferredStyle: UIAlertControllerStyle.alert)
        triunfo.addAction(UIAlertAction(title: "Volver", style: UIAlertActionStyle.default, handler: nil))
        present(triunfo, animated: true, completion: nil)
    }
    func cambioJugador() {
        show(PantallaDos(), sender: nil)
    }
    func botonResetPulsado() {
        acierto = 0
        aciertoDos = 0
        colocadas = 0
        cartasEnJuego = 0
        datoClaveContador = acierto as Int
        datoClaveContadorDos = aciertoDos as Int
        datoClave.set(datoClaveContador, forKey: "acierto")
        datoClave.set(datoClaveContadorDos, forKey: "aciertoDos")
        inventos.removeAll()
        pantallaCartas.reloadData()
        botonCarta.isHidden = false
        viewDidLoad()
    }
    func vuelta(){
        pantallaCartas.setEditing(false, animated: false)
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .edit, target: self, action: #selector(pista))
    }
    
    func pista() {
        pantallaCartas.setEditing(true, animated: true)
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(vuelta))
    }
    var inventos = [Inventos]()
    let datoClave = UserDefaults()
    var datoClaveContador: Int = 0
    var datoClaveContadorDos: Int = 0
    var cartasEnJuego = 0
    var puntos = UILabel(frame: CGRect(x: 50, y: 500, width: 50, height: 50))
    var puntosDos = UILabel(frame: CGRect(x: 50, y: 500, width: 50, height: 50))
    
    //#-end-hidden-code
    var nutreInventos = [Vapor, Bombilla, Automovil, Bicicleta, Avion, Telefono, Cine, fregona, Videoconsola, Radio,/*#-editable-code*//*#-end-editable-code*/]
    
/*:
     
Una vez incorporados los datos, **te recuerdo que puedes incorporar tantos inventos como te plazca**, solo tienes que **salir del libro y volver a entrar**. Hecho esto, `ejecuta el código` y a jugar con tus propios inventos.
     
*/
    //#-hidden-code
    let botonCarta = UIButton(frame: CGRect(x: 15, y: 50, width: 40, height: 40))
    let tituloJuego = UILabel()
    let pantallaCartas = UITableView(frame: CGRect(x: 5, y: 5, width: 600, height: 400))
    let creacion = UILabel(frame: CGRect(x: 150, y: 75, width: 120, height: 35))
    let botonCambioJugador = UIButton(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
    let botonReset = UIButton(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
    
    var acierto = 0
    var aciertoDos = 0
    var colocadas = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if (datoClave.object(forKey: "acierto") == nil) {
          
            
        } else if datoClave.object(forKey: "acierto") as! Int >= 15 {
            acierto = 0
            aciertoDos = 0
            colocadas = 0
            cartasEnJuego = 0
            datoClaveContador = acierto as Int
            datoClaveContadorDos = aciertoDos as Int
            datoClave.set(datoClaveContador, forKey: "acierto")
            datoClave.set(datoClaveContadorDos, forKey: "aciertoDos")
            inventos.removeAll()
            pantallaCartas.reloadData()
            botonCarta.isHidden = false
        } else if datoClave.object(forKey: "aciertoDos") as! Int >= 15 {
            acierto = 0
            aciertoDos = 0
            colocadas = 0
            cartasEnJuego = 0
            datoClaveContador = acierto as Int
            datoClaveContadorDos = aciertoDos as Int
            datoClave.set(datoClaveContador, forKey: "acierto")
            datoClave.set(datoClaveContadorDos, forKey: "aciertoDos")
            inventos.removeAll()
            pantallaCartas.reloadData()
            botonCarta.isHidden = false
            
        } else {
            acierto = datoClave.object(forKey: "acierto") as! Int
            aciertoDos = datoClave.object(forKey: "aciertoDos") as! Int
        }
        
        view.backgroundColor = .white
        botonCambioJugador.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0).withAlphaComponent(0.9)
        botonCambioJugador.layer.cornerRadius = 25
        botonCambioJugador.setTitle("👆🏻", for: .normal)
        botonCambioJugador.layer.borderWidth = 1
        botonCambioJugador.setTitleColor(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0), for: .normal)
        botonCambioJugador.isHidden = true
        botonCambioJugador.addTarget(nil, action: #selector(cambioJugador), for: .touchUpInside)
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .edit, target: self, action: #selector(pista))
        
        botonReset.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        botonReset.layer.cornerRadius = 25
        botonReset.setTitle("✖️", for: .normal)
        botonReset.layer.borderWidth = 1
        botonReset.setTitleColor(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0), for: .normal)
        botonReset.isHidden = false
        botonReset.addTarget(nil, action: #selector(botonResetPulsado), for: .touchUpInside)
        
        
        puntos.layer.borderWidth = 5
        puntos.textAlignment = .center
        puntos.font = UIFont(name: "PingFangTC-Medium", size: 20)
        puntos.text = "\(acierto)"
        puntos.backgroundColor = #colorLiteral(red: 0.474509805440903, green: 0.839215695858002, blue: 0.976470589637756, alpha: 1.0)
        
        puntosDos.layer.borderWidth = 5
        puntosDos.textAlignment = .center
        puntosDos.font = UIFont(name: "PingFangTC-Medium", size: 20)
        puntosDos.text = "\(aciertoDos)"
        puntosDos.backgroundColor = #colorLiteral(red: 0.960784316062927, green: 0.705882370471954, blue: 0.200000002980232, alpha: 1.0)
        puntosDos.isEnabled = false
        
        botonCarta.backgroundColor = .red
        
        botonCarta.layer.cornerRadius = 35
        botonCarta.addTarget(nil, action: #selector(botonCartaPulsa), for: .touchUpInside)
        
        tituloJuego.text = "El huevo o la gallina"
        
        
        tituloJuego.adjustsFontSizeToFitWidth = true
        tituloJuego.textAlignment = .center
        tituloJuego.font = UIFont(name: "PingFangSC-Thin", size: 40)
        pantallaCartas.layer.cornerRadius = 15
        pantallaCartas.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        self.pantallaCartas.delegate = self
        self.pantallaCartas.dataSource = self
        
        pantallaCartas.rowHeight = 150
        pantallaCartas.reloadData()
        
        view.addSubview(pantallaCartas)
        view.addSubview(tituloJuego)
        view.addSubview(botonCarta)
        view.addSubview(botonCambioJugador)
        view.addSubview(puntos)
        view.addSubview(puntosDos)
        view.addSubview(botonReset)
        
        botonReset.translatesAutoresizingMaskIntoConstraints = false
        puntos.translatesAutoresizingMaskIntoConstraints = false
        tituloJuego.translatesAutoresizingMaskIntoConstraints = false
        pantallaCartas.translatesAutoresizingMaskIntoConstraints = false
        botonCarta.translatesAutoresizingMaskIntoConstraints = false
        botonCambioJugador.translatesAutoresizingMaskIntoConstraints = false
        puntosDos.translatesAutoresizingMaskIntoConstraints = false
        
        let views = ["tituloJuego": tituloJuego, "pantallaCartas": pantallaCartas, "botonCarta": botonCarta, "botonCambioJugador": botonCambioJugador, "puntos": puntos, "botonReset": botonReset, "puntosDos": puntosDos]
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "|-25-[botonCarta(70)]", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "|-25-[tituloJuego]-25-|", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "|-35-[pantallaCartas]-35-|", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "|-25-[botonCambioJugador(50)]", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "[botonReset(50)]-25-|", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "|-25-[puntos(50)]", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "[puntosDos(50)]-25-|", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-50-[tituloJuego]-5-[pantallaCartas]-8-|", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-100-[botonCarta(70)]", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-250-[botonCambioJugador(50)]", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-250-[botonReset(50)]", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:[puntos(50)]-25-|", options: [], metrics: nil, views: views))
        
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:[puntosDos(50)]-25-|", options: [], metrics: nil, views: views))
    }
    func botonCartaPulsa(){
        if nutreInventos.count == 0 {
            title = "No hay más elementos."
        }else {
            for _ in 1 ... 3 {
                botonCarta.isHidden = true
                let randomChoice = GKRandomDistribution(lowestValue: 0, highestValue: nutreInventos.count - 1)
                let sign = randomChoice.nextInt()
                cartasEnJuego += 1
                print(cartasEnJuego)
                inventos.insert(nutreInventos[sign], at: 0)
                nutreInventos.remove(at: sign)
                
                pantallaCartas.beginUpdates()
                pantallaCartas.insertRows(at: [IndexPath.init(row: 0, section: 0)], with: UITableViewRowAnimation.left)
                pantallaCartas.endUpdates()
                
            }
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return inventos.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = UITableViewCell(style: .value2, reuseIdentifier: "celdaInventos")
        celda.backgroundColor = .white
        let fondoCarta = UIView(frame: CGRect(x: 60, y: 15, width: 25, height: 25))
        let imagenInvento = UIImageView(frame: CGRect(x: 25, y: 55, width: 100, height: 70))
        let nombreInvento = UILabel(frame: CGRect(x: 15, y: 15, width: 125, height: 35))
        let textoInvento = UILabel(frame: CGRect(x: 10, y: 168, width: 130, height: 70))
        
        
        fondoCarta.layer.cornerRadius = 8
        
        imagenInvento.layer.cornerRadius = 8
        imagenInvento.image = inventos[indexPath.row].imagenInvento
        
        nombreInvento.text = inventos[indexPath.row].nombre
        nombreInvento.textAlignment = .center
        
        nombreInvento.font = UIFont(name: "PingFangSC-Thin", size: 25)
        nombreInvento.textColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        nombreInvento.adjustsFontSizeToFitWidth = true
        
        textoInvento.numberOfLines = 0
        textoInvento.textAlignment = .center
        textoInvento.backgroundColor = .white
        textoInvento.textColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        textoInvento.font = UIFont(name: "PingFangSC-Thin", size: 15)
        
        fondoCarta.addSubview(imagenInvento)
        fondoCarta.addSubview(nombreInvento)
        fondoCarta.addSubview(creacion)
        celda.contentView.addSubview(fondoCarta)
        
        fondoCarta.translatesAutoresizingMaskIntoConstraints = false
        imagenInvento.translatesAutoresizingMaskIntoConstraints = false
        
        nombreInvento.translatesAutoresizingMaskIntoConstraints = false
        
        let vistaCeldas = ["fondoCarta": fondoCarta, "imagenInvento": imagenInvento, "nombreInvento": nombreInvento, "creacion": creacion]
        
        celda.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "|-50-[fondoCarta]-50-|", options: [], metrics: nil, views: vistaCeldas))
        
        fondoCarta.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "|-40-[imagenInvento(80)]-10-|", options: [], metrics: nil, views: vistaCeldas))
        
        fondoCarta.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "|-5-[creacion(10)]", options: [], metrics: nil, views: vistaCeldas))
        
        fondoCarta.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "|-25-[nombreInvento]-10-|", options: [], metrics: nil, views: vistaCeldas))
        
        celda.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-5-[fondoCarta]-5-|", options: [], metrics: nil, views: vistaCeldas))
        
        fondoCarta.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-8-[nombreInvento]-10-[imagenInvento(80)]", options: [], metrics: nil, views: vistaCeldas))
        
        fondoCarta.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-15-[creacion(30)]", options: [], metrics: nil, views: vistaCeldas))
        
        fondoCarta.setNeedsDisplay()
        imagenInvento.setNeedsDisplay()
        nombreInvento.setNeedsDisplay()
        creacion.setNeedsDisplay()
        
        return celda
    }
    func tableView(_ tableView: UITableView, canFocusRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let pulsado = inventos[indexPath.row]
        let celdaSelccionada = pantallaCartas.cellForRow(at: indexPath)
        let datos = UIAlertController(title: pulsado.nombre, message: pulsado.pista, preferredStyle: UIAlertControllerStyle.alert)
        datos.addAction(UIAlertAction(title: "Volver", style: UIAlertActionStyle.default, handler: nil))
        present(datos, animated: true, completion: nil)
        
        celdaSelccionada?.isEditing = true
        
        
    }
    
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let itemToMove = inventos[sourceIndexPath.row]
        inventos.remove(at: sourceIndexPath.row)
        inventos.insert(itemToMove, at: destinationIndexPath.row)
        let posicion = destinationIndexPath.row
        let posicionArriba = destinationIndexPath.row - 1
        let posicionaAbajo = destinationIndexPath.row + 1
        _ = cartasEnJuego - 1
        let celdaEnJuego = pantallaCartas.cellForRow(at: sourceIndexPath)
        _ = 0
        
        if posicion == 0 {
            if itemToMove.añoInvento > inventos[posicionaAbajo].añoInvento{
                celdaEnJuego?.isEditing = false
                celdaEnJuego?.backgroundColor = #colorLiteral(red: 0.466666668653488, green: 0.764705896377563, blue: 0.266666680574417, alpha: 1.0)
                acierto += 1
                puntos.text = "\(acierto)"
                datoClaveContador = acierto as Int
                datoClave.set(datoClaveContador, forKey: "acierto")
                
                
                
                let creacion = UILabel(frame: CGRect(x: 200, y: 75, width: 120, height: 60))
                creacion.textColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
                creacion.font = UIFont(name: "PingFangSC-Thin", size: 40)
                creacion.textAlignment = .center
                creacion.text = itemToMove.numero
                celdaEnJuego?.contentView.addSubview(creacion)
                colocadas += 1
                if colocadas == 3 {
                    botonCambioJugador.isHidden = false
                    botonReset.isHidden = true
                }
                if acierto == 15 {
                    ganador()
                }
            } else {
                celdaEnJuego?.isEditing = false
                celdaEnJuego?.backgroundColor = #colorLiteral(red: 0.925490200519562, green: 0.235294118523598, blue: 0.10196078568697, alpha: 1.0)
                colocadas += 1
                if colocadas == 3 {
                    botonCambioJugador.isHidden = false
                    botonReset.isHidden = true
                }
            }}
        if posicion == 1 {
            
            if itemToMove.añoInvento < inventos[posicionArriba].añoInvento && itemToMove.añoInvento > inventos[posicionaAbajo].añoInvento{
                celdaEnJuego?.isEditing = false
                celdaEnJuego?.backgroundColor = #colorLiteral(red: 0.466666668653488, green: 0.764705896377563, blue: 0.266666680574417, alpha: 1.0)
                acierto += 1
                puntos.text = "\(acierto)"
                datoClaveContador = acierto as Int
                datoClave.set(datoClaveContador, forKey: "acierto")
                
                let creacion = UILabel(frame: CGRect(x: 200, y: 75, width: 120, height: 60))
                
                creacion.textColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
                creacion.font = UIFont(name: "PingFangSC-Thin", size: 40)
                creacion.textAlignment = .center
                creacion.text = itemToMove.numero
                celdaEnJuego?.contentView.addSubview(creacion)
                colocadas += 1
                if colocadas == 3 {
                    botonCambioJugador.isHidden = false
                    botonReset.isHidden = true
                }
                if acierto == 15 {
                    ganador()
                }
            }else {
                celdaEnJuego?.isEditing = false
                celdaEnJuego?.backgroundColor = #colorLiteral(red: 0.925490200519562, green: 0.235294118523598, blue: 0.10196078568697, alpha: 1.0)
                colocadas += 1
                if colocadas == 3 {
                    botonCambioJugador.isHidden = false
                    botonReset.isHidden = true
                }
            }
        }
        if posicion == 2  {
            if itemToMove.añoInvento < inventos[posicionArriba].añoInvento {
                celdaEnJuego?.isEditing = false
                celdaEnJuego?.backgroundColor = #colorLiteral(red: 0.466666668653488, green: 0.764705896377563, blue: 0.266666680574417, alpha: 1.0)
                acierto += 1
                puntos.text = "\(acierto)"
                datoClaveContador = acierto as Int
                datoClave.set(datoClaveContador, forKey: "acierto")
                let creacion = UILabel(frame: CGRect(x: 200, y: 75, width: 120, height: 60))
                creacion.font = UIFont(name: "PingFangSC-Thin", size: 40)
                creacion.textAlignment = .center
                creacion.text = itemToMove.numero
                creacion.textColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
                
                celdaEnJuego?.contentView.addSubview(creacion)
                colocadas += 1
                if colocadas == 3 {
                    botonCambioJugador.isHidden = false
                    botonReset.isHidden = true
                }
                if acierto == 15 {
                    ganador()
                }
            }else{
                celdaEnJuego?.isEditing = false
                celdaEnJuego?.backgroundColor = #colorLiteral(red: 0.925490200519562, green: 0.235294118523598, blue: 0.10196078568697, alpha: 1.0)
                colocadas += 1
                if colocadas == 3 {
                    botonCambioJugador.isHidden = false
                    botonReset.isHidden = true
                }
            }
            
        }
        
    }
}
PlaygroundPage.current.liveView = UINavigationController(rootViewController: Pantalla())
//#-end-hidden-code
