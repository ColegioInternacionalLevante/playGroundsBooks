/*:
#  El huevo o la gallina
### Un PlaygrounBook para saber qué fue antes
 
Como su nombre indica, este `PlaygrounBook` te servirá para ubicar hechos o elementos cronológicamente en una línea temporal y también para crear tu propio juego con contenido personalizado dentro del formato propuesto.
 
 Déjame un minuto para explicarte cómo funciona la aplicación. Una vez ejecutes el código aparecerá esta pantalla:
 
 ![Imagen App inicio](HUEVO1.JPEG)
 
 - 1. Todo comienza pulsando el punto rojo. Cuando lo hagas aparecerán tres filas con el nombre de un invento y su imagen. *(Como se ve en la imagen inferior)*
 
 - 2. Pulsando el botón `Editar` entras en modo `edición`. Pulsando `cancelar` vuelves al modo `pista`.
 
 - 3. El botón `Reset` te permite cancelar la partida en cualquier momento y poner los contadores a cero.
 
 - 4. Los cuadros de abajo en diferente color son los marcadores.
 
 ![Imagen App inicio](HUEVO2.JPEG)
 
 COmo he dicho, pulsando el botón rojo aparecen tres elementos en pantalla. Si estás en modo `pista` *(que es el que se muestra en la imagen superior)* y pulsas en cualquiera de las filas aparecerá un cuadro de texto dándote alguna clave sobre cuál podría ser la ubicación del objeto en cuestión.
 
 ![Imagen App inicio](HUEVO3OK.JPEG)
 
 Una vez consultadas las pistas, si lo has hecho ya que no es obligatorio, debes entrar en modo `edición` para continuar el juego. En este modo verás que las filas cambian de aspecto:

#### Imagen 1
 
- En el lado izquierdo aparece el símpolo de prohibición, que en este juego no usaremos.
- En el lado derecho aparecen tres rayitas paralelas. Es sobre estas rayitas donde debes pulsar para mover la fila a otro lugar o confirmar que se encuentra en el lugar adecuado.
 
#### Imagen 2
 
 ¡OJO! Una vez seleccionas una fila ya no hay vuelta atrás. La debes colocar en algún sitio o volverla a dejar donde estaba.
 
#### Imagen 3
 
 Si has colocado la fila en el lugar cronológico correcto, la celda se volverá verde, aparecerá el año del objeto y se sumará un punto a tu casillero. Si no es así, la celda se volverá roja. Pero no todo está perdido ya que no habrá penalización.
 
#### Imagen 4
 
 Recuerda que en la parte superior de la pantalla debemos colocar los más actuales y abajo los más antiguos.
 
 El primer jugador en acumular **15 puntos** será el ganador.
 
*/
